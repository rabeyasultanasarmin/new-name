package com.example.firstProject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/api/data")
public class DataController {

    @Autowired
    private DataService jsonDataService;

    // GET all data
    @GetMapping
    public List<DataItem> getAllData() throws IOException {
        return jsonDataService.getAllData();
    }

    // POST new data
    @PostMapping
    public DataItem createData(@RequestBody DataItem newDataItem) throws IOException {
        return jsonDataService.createData(newDataItem);
    }

    // PUT update data by ID
    @PutMapping("/{id}")
    public DataItem updateData(@PathVariable String id, @RequestBody DataItem updatedData) throws IOException {
        return jsonDataService.updateData(id, updatedData);
    }

    // DELETE data by ID
    @DeleteMapping("/{id}")
    public boolean deleteData(@PathVariable String id) throws IOException {
        return jsonDataService.deleteData(id);
    }
}
