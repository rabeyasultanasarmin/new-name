package com.example.firstProject;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Service
public class DataService {

    private final String FILE_PATH = "data.json";
    private final ObjectMapper objectMapper = new ObjectMapper();

    // Load data from JSON file
    private List<DataItem> loadData() throws IOException {
        File file = new File(FILE_PATH);
        if (!file.exists()) {
            return new ArrayList<>();
        }
        return objectMapper.readValue(file, objectMapper.getTypeFactory().constructCollectionType(List.class, DataItem.class));
    }

    // Save data to JSON file
    private void saveData(List<DataItem> dataItems) throws IOException {
        objectMapper.writeValue(new File(FILE_PATH), dataItems);
    }

    // Create a new DataItem
    public DataItem createData(DataItem newDataItem) throws IOException {
        List<DataItem> dataItems = loadData();
        newDataItem.setId(String.valueOf(dataItems.size() + 1));  // Simple id generator
        dataItems.add(newDataItem);
        saveData(dataItems);
        return newDataItem;
    }

    // Read all DataItems
    public List<DataItem> getAllData() throws IOException {
        return loadData();
    }

    // Update a DataItem by ID
    public DataItem updateData(String id, DataItem updatedData) throws IOException {
        List<DataItem> dataItems = loadData();
        for (DataItem item : dataItems) {
            if (item.getId().equals(id)) {
                item.setName(updatedData.getName());
                item.setValue(updatedData.getValue());
                saveData(dataItems);
                return item;
            }
        }
        return null;
    }

    // Delete a DataItem by ID
    public boolean deleteData(String id) throws IOException {
        List<DataItem> dataItems = loadData();
        boolean removed = dataItems.removeIf(item -> item.getId().equals(id));
        if (removed) {
            saveData(dataItems);
        }
        return removed;
    }
}
